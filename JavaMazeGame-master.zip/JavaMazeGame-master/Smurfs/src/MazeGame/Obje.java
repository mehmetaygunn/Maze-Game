package MazeGame;

public class Obje {
	
	private int TileX;
	private int TileY;
	public int getTileX() {
		return TileX;
	}
	public void setTileX(int tileX) {
		TileX = tileX;
	}
	public int getTileY() {
		return TileY;
	}
	public void setTileY(int tileY) {
		TileY = tileY;
	}

}

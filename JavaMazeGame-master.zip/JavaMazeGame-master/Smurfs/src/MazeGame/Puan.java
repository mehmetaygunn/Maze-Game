package MazeGame;

public class Puan {

	private int puan;
	
	public Puan(int puan) {
		this.puan=puan;
		
	}

	public int getuan() {
		return puan;
	}

	public void setPuan(int puan) {
		this.puan = puan;
		
	}
	
	
}

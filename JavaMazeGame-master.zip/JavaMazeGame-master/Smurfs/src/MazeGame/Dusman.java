package MazeGame;

public class Dusman extends Karakter {

	public Dusman(int tileX, int tileY, int id, String ad, String t�r) {
		super(tileX, tileY, id, ad, t�r);
		
	}
	
}

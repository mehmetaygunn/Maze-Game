package MazeGame;

import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class KarakterEkrani extends JPanel {

	/**
	 * Create the panel.
	 */
	Player player;
	public KarakterEkrani() {
		setLayout(null);
		int a=0;
		
		

	}

}
